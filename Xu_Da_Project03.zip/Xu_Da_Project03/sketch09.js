let video;
let poseNet;
let poses = [];

var segmentCount = 360;
var radius = 300;

var myRec = new p5.SpeechRec(); // new P5.SpeechRec object



var myVoice = new p5.Speech();
var menuLoaded = 0;
var label, input, checkbox, speakbutton, vslider, rslider, pslider;

function setup() {
    createCanvas(500, 500);
    background(255, 255, 255);
    noStroke();
    fill(0, 0, 0, 255);

    video = createCapture(VIDEO);
    video.size(width, height);


    poseNet = ml5.poseNet(video, {
        outputStride: 8,
        quantBytes: 4
    }, modelReady);

    poseNet.on('pose', function (results) {
        poses = results;
    });

    video.hide();
 
    myRec.onResult = showResult;
    myRec.start();

}

function modelReady() {
    select('#status').html('Model Loaded');
}

function mousePressed() {
    console.log(JSON.stringify(poses))
}

function draw() {


    //    image(video, 0, 0, width, height);
    //    strokeWeight(2);
    //    filter(THRESHOLD, 1);

    textSize(32);
    textAlign(CENTER);
    fill(0)
    text("say something", width / 2, 350);



    if (poses.length > 0) {
        const pose = poses[0].pose;
        console.log(pose);


        const nose = pose.nose;

        colorMode(HSB, 360, width, height);
        background(360, 0, height);

        var angleStep = 360 / segmentCount;

        beginShape(TRIANGLE_FAN);
        vertex(width / 2, height / 2);

        for (var angle = 0; angle <= 360; angle += angleStep) {
            var vx = width / 2 + cos(radians(angle)) * radius;
            var vy = height / 2 + sin(radians(angle)) * radius;
            vertex(vx, vy);
            fill(angle, nose.x, nose.y);
        }

        endShape();



                fill(255, 192, 200);
                text(myRec.resultString, nose.x, nose.y);




    }
}




function showResult() {

}






///////////////////////////////////////////////////////////////////////////////////////
//reference
// Generative Gestaltung – Creative Coding im Web
// ISBN: 978-3-87439-902-9, First Edition, Hermann Schmidt, Mainz, 2018
// Benedikt Groß, Hartmut Bohnacker, Julia Laub, Claudius Lazzeroni
// with contributions by Joey Lee and Niels Poldervaart
// Copyright 2018
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


//var segmentCount = 360;
//var radius = 300;
//
//function setup() {
//  createCanvas(800, 800);
//  noStroke();
//}
//
//function draw() {
//  colorMode(HSB, 360, width, height);
//  background(360, 0, height);
//
//  var angleStep = 360 / segmentCount;
//
//  beginShape(TRIANGLE_FAN);
//  vertex(width / 2, height / 2);
//
//  for (var angle = 0; angle <= 360; angle += angleStep) {
//    var vx = width / 2 + cos(radians(angle)) * radius;
//    var vy = height / 2 + sin(radians(angle)) * radius;
//    vertex(vx, vy);
//    fill(angle, mouseX, mouseY);
//  }
//
//  endShape();
//}
